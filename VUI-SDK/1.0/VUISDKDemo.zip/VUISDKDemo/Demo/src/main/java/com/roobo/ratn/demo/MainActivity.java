package com.roobo.ratn.demo;

import android.content.Context;
import android.graphics.Color;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.roobo.ratn.demo.source.CustomAndroidAudioGenerator;
import com.roobo.toolkit.RError;
import com.roobo.toolkit.recognizer.OnAIResponseListener;
import com.roobo.toolkit.recognizer.RooboRecognizer;
import com.roobo.vui.api.AutoTypeController;
import com.roobo.vui.api.IASRController;
import com.roobo.vui.api.InitListener;
import com.roobo.vui.api.VUIApi;
import com.roobo.vui.api.asr.RASRListener;
import com.roobo.vui.api.tts.RTTSListener;
import com.roobo.vui.api.tts.RTTSPlayer;
import com.roobo.vui.common.recognizer.ASRResult;
import com.roobo.vui.common.recognizer.EventType;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private RadioGroup rgMic, rgRec, mTTSType;
    private Button init, start, stop, touch_start, mTTSBtn, manualWakeup, sleep, pseudoSleep, cancelPseudoSleep, mAIQueryBtn, mSetAIContextBtn, mCancelAIContext;
    private View autoControllerView, ttsControllerView, aiControllerView, initParantView;
    VUIApi mVUI = null;
    final Handler handler = new Handler();
    private RTTSPlayer.TTSType ttsType;
    private IASRController mASRController;
    private VUIApi.VUIType vuiType;
    private EditText mTts, mLang, mAIQueryContent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
    }

    private void initViews() {
        initParamsViews();
        initControllerViews();
        resetButton();
    }

    private void initParamsViews() {
        // Example of a call to a native method
        TextView tv = (TextView) findViewById(R.id.sample_text);
        tv.setText("选确认你的设备，在继续");
        rgMic = (RadioGroup) findViewById(R.id.rg_mic);
        rgRec = (RadioGroup) findViewById(R.id.rg_rec);
        rgMic.setOnCheckedChangeListener(onCheckedChangeListener);
        rgRec.setOnCheckedChangeListener(onCheckedChangeListener);
        init = (Button) findViewById(R.id.init);
        init.setOnClickListener(onClickListener);
        mTTSType = (RadioGroup) findViewById(R.id.rg_tts);
        mTTSType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
                init.setVisibility(View.VISIBLE);
                resetButton();
                if (i == R.id.rb_online) {
                    ttsType = RTTSPlayer.TTSType.TYPE_ONLINE;
                } else {
                    ttsType = RTTSPlayer.TTSType.TYPE_OFFLINE;
                }
            }
        });
        initParantView = findViewById(R.id.initParant);
    }

    private void initControllerViews() {
        start = (Button) findViewById(R.id.start);
        stop = (Button) findViewById(R.id.stop);
        touch_start = (Button) findViewById(R.id.touch_start);
        start.setOnClickListener(onClickListener);
        stop.setOnClickListener(onClickListener);
        touch_start.setOnTouchListener(touchListener);
        mTts = (EditText) findViewById(R.id.tts);
        mLang = (EditText) findViewById(R.id.lang);
        mTTSBtn = (Button) findViewById(R.id.tts_btn);
        mTTSBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String p = mTts.getText().toString();
                if (!TextUtils.isEmpty(mLang.getText().toString())) {
                    VUIApi.getInstance().setSpeaker(mLang.getText().toString());
                }
                VUIApi.getInstance().speak(p, new RTTSListener() {

                    @Override
                    public void onSpeakBegin() {
                        Log.d(TAG, "onSpeakBegin");
                        Toast.makeText(getApplicationContext(), "speak", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCompleted() {
                        Log.d(TAG, "onCompleted");
                    }

                    @Override
                    public void onError(int code) {
                        Log.d(TAG, "onError " + code);
                    }
                });
                Toast.makeText(getApplicationContext(), "synthesis", Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.tts_stop).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VUIApi.getInstance().stopSpeak();
            }
        });
        mTTSType = (RadioGroup) findViewById(R.id.rg_tts);
        mTTSType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
                init.setVisibility(View.VISIBLE);
                resetButton();
                if (i == R.id.rb_online) {
                    ttsType = RTTSPlayer.TTSType.TYPE_ONLINE;
                } else {
                    ttsType = RTTSPlayer.TTSType.TYPE_OFFLINE;
                }
            }
        });
        autoControllerView = findViewById(R.id.autoController);
        manualWakeup = (Button) findViewById(R.id.manualWakeup);
        manualWakeup.setOnClickListener(onClickListener);
        sleep = (Button) findViewById(R.id.sleep);
        sleep.setOnClickListener(onClickListener);
        pseudoSleep = (Button) findViewById(R.id.pseudoSleep);
        pseudoSleep.setOnClickListener(onClickListener);
        cancelPseudoSleep = (Button) findViewById(R.id.cancelPseudoSleep);
        cancelPseudoSleep.setOnClickListener(onClickListener);
        ttsControllerView = findViewById(R.id.ttsParent);
        aiControllerView = findViewById(R.id.aiParent);
        mAIQueryBtn = (Button) findViewById(R.id.query);
        mAIQueryBtn.setOnClickListener(onClickListener);
        mSetAIContextBtn = (Button) findViewById(R.id.setContext);
        mSetAIContextBtn.setOnClickListener(onClickListener);
        mAIQueryContent = (EditText) findViewById(R.id.aiQuery);
        mCancelAIContext = (Button) findViewById(R.id.cancelContext);
        mCancelAIContext.setOnClickListener(onClickListener);
    }

    RadioGroup.OnCheckedChangeListener onCheckedChangeListener = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
            init.setVisibility(View.VISIBLE);
            resetButton();
        }
    };

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v == start) {
                if (checkRecordStateSuccess()) {
                    mASRController = mVUI.startRecognize();
                    if (vuiType == VUIApi.VUIType.AUTO) {
                        autoControllerView.setVisibility(View.VISIBLE);
                    }
                } else {
                    //请检查录音权限及AudioRecorder是否被占用
                    Toast.makeText(MainActivity.this, "请检查录音权限及AudioRecorder是否被占用", Toast.LENGTH_SHORT).show();
                }
            } else if (v == stop) {
                mVUI.stopRecognize();
            } else if (v == init) {
                init.setVisibility(View.GONE);
                resetButton();
                if (mVUI != null) {
                    mVUI.release();
                } else {
                    mVUI = mVUI.getInstance();
                }
                int checkedRadioButtonId = rgMic.getCheckedRadioButtonId();
                VUIApi.SourceType micModel;
                if (checkedRadioButtonId == R.id.rb_android) {
                    micModel = VUIApi.SourceType.ANDROID_STANDARD;
                } else if (checkedRadioButtonId == R.id.rb_3399) {
                    micModel = VUIApi.SourceType.MIC_ARRAY_RK3399;
                } else {
                    micModel = VUIApi.SourceType.MIC_ARRAY_R16;
                }

                String wakeupGrammarFile = "test_offline";

                int recId = rgRec.getCheckedRadioButtonId();
                if (recId == R.id.rb_sustained_wakeup_cloud) { // 持续按唤醒
                    vuiType = VUIApi.VUIType.AUTO;
                    VUIApi.InitParam.InitParamBuilder builder = new VUIApi.InitParam.InitParamBuilder();
                    builder.setLanguage("cmn-CHN").setMicModel(micModel).addOfflineFileName(wakeupGrammarFile).setTTSType(ttsType).setVUIType(VUIApi.VUIType.AUTO).setAudioGenerator(new CustomAndroidAudioGenerator());
                    mVUI.init(MainActivity.this, builder.build(),
                            new InitListener() {
                                @Override
                                public void onSuccess() {
                                    Log.d(TAG, "onSucess: called");
                                    setListener();
                                    start.setVisibility(View.VISIBLE);
                                    stop.setVisibility(View.VISIBLE);
                                    mTTSBtn.setVisibility(View.VISIBLE);
                                    updateView();
                                    reprotLocation();
                                }

                                @Override
                                public void onFail(RError rError) {
                                    Log.d(TAG, "onFail: " + rError.getFailDetail());
                                }
                            });

                } else if (recId == R.id.rb_manual_vad) { // 手动控制vad
                    vuiType = VUIApi.VUIType.MANUAL;
                    VUIApi.InitParam.InitParamBuilder builder = new VUIApi.InitParam.InitParamBuilder();
                    builder.setLanguage("cmn-CHN").setMicModel(micModel).addOfflineFileName(wakeupGrammarFile).setTTSType(ttsType).setVUIType(VUIApi.VUIType.MANUAL).setAudioGenerator(new CustomAndroidAudioGenerator());
                    mVUI.init(MainActivity.this, builder.build(),
                            new InitListener() {
                                @Override
                                public void onSuccess() {
                                    Log.d(TAG, "onSucess: called");
                                    setListener();
                                    touch_start.setVisibility(View.VISIBLE);
                                    mTTSBtn.setVisibility(View.VISIBLE);
                                    reprotLocation();
                                    updateView();
                                }

                                @Override
                                public void onFail(RError rError) {
                                    Log.d(TAG, "onFail: " + rError.getFailDetail());
                                }
                            });

                }

            } else if (v == manualWakeup) {
                if (mASRController instanceof AutoTypeController) {
                    ((AutoTypeController) mASRController).manualWakeup();
                }
            } else if (v == sleep) {
                if (mASRController instanceof AutoTypeController) {
                    ((AutoTypeController) mASRController).sleep();
                }
            } else if (v == pseudoSleep) {
                if (mASRController instanceof AutoTypeController) {
                    ((AutoTypeController) mASRController).pseudoSleep();
                }
            } else if (v == cancelPseudoSleep) {
                if (mASRController instanceof AutoTypeController) {
                    ((AutoTypeController) mASRController).cancelPseudoSleep();
                }
            } else if (v == mAIQueryBtn) {
                String content = mAIQueryContent.getText().toString();
                if (!TextUtils.isEmpty(content)) {
                    mVUI.aiQuery(content);
                }
            } else if (v == mSetAIContextBtn) {
                String context = "[{\"context\":\"zh_en_translation\", \"service\":\"Translator\" }]";
                mVUI.setAIContext(context);
            } else if (v == mCancelAIContext) {
                mVUI.setAIContext("");
            }
        }
    };


    View.OnTouchListener touchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    //按下
                    if (checkRecordStateSuccess()) {
                        mVUI.startRecognize();
                        v.setBackgroundColor(Color.RED);
                    } else {
                        //请检查录音权限及AudioRecorder是否被占用
                        Toast.makeText(MainActivity.this, "请检查录音权限及AudioRecorder是否被占用", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    //抬起
                    mVUI.stopRecognize();
                    v.setBackgroundColor(Color.GREEN);
                    break;

            }
            return true;
        }
    };

    private void setListener() {
        mVUI.setASRListener(new RASRListener() {
            @Override
            public void onASRResult(final ASRResult result) {
                Log.d(TAG, "ASRResult " + (result.getResultType() == ASRResult.TYPE_OFFLINE ? "offline " : " online ") + " text " + result.getResultText());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        TextView viewById = (TextView) findViewById(R.id.text);
                        viewById.setText(result.getResultText());
                    }
                });
            }

            @Override
            public void onFail(final RError message) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        TextView viewById = (TextView) findViewById(R.id.text);
                        viewById.setText("asr error " + message.getFailCode() + " " + message.getFailDetail());
                    }
                });
            }

            @Override
            public void onWakeUp(final String json) {
                Log.d(TAG, "onWakeup: " + json);
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        TextView viewById = (TextView) findViewById(R.id.text);
                        viewById.setText(json);
                        mVUI.stopSpeak();
                    }
                });
            }

            @Override
            public void onEvent(EventType event) {
                Log.d(TAG, "EventType: " + event);
            }
        });


        mVUI.setOnAIResponseListener(new OnAIResponseListener() {
            @Override
            public void onResult(final String json) {
                Log.d(TAG, "onAIResponse: " + json);
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        TextView viewById = (TextView) findViewById(R.id.text);
                        viewById.setText(json);
                    }
                });
            }

            @Override
            public void onFail(final RError rError) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        TextView viewById = (TextView) findViewById(R.id.text);
                        viewById.setText("AI error " + rError.getFailCode() + " " + rError.getFailDetail());
                    }
                });
            }
        });
    }

    private void resetButton() {
        start.setVisibility(View.GONE);
        stop.setVisibility(View.GONE);

        touch_start.setVisibility(View.GONE);
        mTTSBtn.setVisibility(View.GONE);
        autoControllerView.setVisibility(View.GONE);
        ttsControllerView.setVisibility(View.GONE);
        aiControllerView.setVisibility(View.GONE);
        initParantView.setVisibility(View.VISIBLE);
    }

    private void updateView() {
        ttsControllerView.setVisibility(View.VISIBLE);
        aiControllerView.setVisibility(View.VISIBLE);
        initParantView.setVisibility(View.GONE);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        System.exit(0);
    }

    private void reprotLocation() {
        WifiManager wifiManager = (WifiManager) getApplication().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        mVUI.reportLocationInfo(wifiManager.getScanResults());

//        mVUI.reportLocationInfo("22.5375738","113.9568349","中国","广东省","深圳市","广东省 深圳市 南山区 科技南十二路 靠近交通银行(深圳高新园支行)");
    }

    public static boolean checkRecordStateSuccess() {
        int minBuffer = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioRecord audioRecord = new AudioRecord(MediaRecorder.AudioSource.DEFAULT, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, (minBuffer * 2));
        short[] point = new short[minBuffer];
        int readSize = 0;
        try {
            audioRecord.startRecording();//检测是否可以进入初始化状态
        } catch (Exception e) {
            if (audioRecord != null) {
                audioRecord.release();
                audioRecord = null;
                Log.d("CheckAudioPermission", "无法进入录音初始状态");
            }
            return false;
        }
        if (audioRecord.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
            //6.0以下机型都会返回此状态，故使用时需要判断bulid版本
            //检测是否在录音中
            if (audioRecord != null) {
                audioRecord.stop();
                audioRecord.release();
                audioRecord = null;
                Log.d("CheckAudioPermission", "录音机被占用");
            }
            return false;
        } else {
            //检测是否可以获取录音结果

            readSize = audioRecord.read(point, 0, point.length);
            if (readSize <= 0) {
                if (audioRecord != null) {
                    audioRecord.stop();
                    audioRecord.release();
                    audioRecord = null;

                }
                Log.d("CheckAudioPermission", "录音的结果为空");
                return false;

            } else {
                if (audioRecord != null) {
                    audioRecord.stop();
                    audioRecord.release();
                    audioRecord = null;

                }

                return true;
            }
        }
    }

}
